export const PROFILE = Object.freeze({
  brand_name: "تصفيات قلقيلية",

  shipping: {
    days_min: 3,
    days_max: 6,
    fees_ils: {
      west_bank: 20,
      jerusalem: 30,
      inside_1948: 75
    },
    jerusalem_keywords: ["القدس", "jerusalem", "واد الجوز", "باب العامود"],
    jerusalem_suburbs_keywords: ["ضواحي القدس", "ضواحي"],
    inside_1948_examples: [
      "جلجولية", "الطيبة", "الطيرة", "كفر قاسم", "أم الفحم",
      "باقة الغربية", "اللد", "الرملة", "حيفا", "الناصرة", "يافا", "نتانيا"
    ]
  },

  branches: [
    {
      name: "فرع رام الله — الماصيون",
      address: "رام الله - الماصيون - بجانب بنك الصفا",
      maps: "https://maps.app.goo.gl/NNyeL2dNdhnXqwQy6"
    },
    {
      name: "فرع رام الله — شارع القدس",
      address: "رام الله - شارع القدس - مقابل عرابي",
      maps: "https://maps.app.goo.gl/MUbQUme7Hn3Ui1HaA"
    }
  ],

  replies_shami: {
    ask_more_for_products:
      "أكيد 😊 بس حتى أساعدك صح: بدك **رجالي ولا نسائي**؟ وعندك **مقاس**؟ وكم ميزانيتك تقريبًا؟",

    policy_exchange_only:
      "أكيد 😊 سياسة **التبديل**: مسموح التبديل خلال **24 ساعة** ومع **الفاتورة**. ورسوم التبديل حسب المنطقة.",

    policy_return_only:
      "بكل محبة 😊 **ما في إرجاع** بعد الشراء. المتاح هو **التبديل فقط** خلال **24 ساعة** ومع **الفاتورة**.",

    policy_shipping_intro:
      "أكيد 😊 التوصيل عادة بين **3 إلى 6 أيام عمل**. احكيلي اسم المدينة وبطلعلك رسوم التوصيل فورًا."
  }
});
